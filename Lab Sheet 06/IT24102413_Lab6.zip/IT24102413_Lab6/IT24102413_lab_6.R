setwd("C://Users//Welcome//Documents//PS//IT24102413_Lab6")

# Part 01

# Question 1
# Binomial Distribution
# Random variable X has binomial distribution with n=50, p=0.85

# Question 2
# It ask to find P(X >= 47)
pbinom(46, 50, 0.85, lower.tail = FALSE)

# Part 02

# Question 1
# Number of calls received in an hour

# Question 2
# Poisson Distribution
# Random variable X has poisson distribution with lamda=12

# Question 3
dpois(12, 15)