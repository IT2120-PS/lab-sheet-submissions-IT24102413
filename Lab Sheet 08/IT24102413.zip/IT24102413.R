setwd("C://Users//Welcome//Desktop//IT24102413_Lab08")
data<-read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)

# Question 01
popmn<-mean(Weight.kg.)
popmn
popsd <- sd(Weight.kg.)
popsd


# Question 02
samples <- c()
n <- c()

for (i in 1:25) {
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste("s", i, sep = ""))
}
n
colnames(samples) = n


# Question 3
s.means <- apply(samples, 2, mean)
samplemean <- mean(s.means)
sample_sds <- sd(s.means)

samplemean
sample_sds



